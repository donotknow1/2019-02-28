package com.bank.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="fund_transfer")
public class FundTransfer {
	
	@Id
	  private int fundId;
	  private int senderAccountNum;
	  private String transpwd;
	  private int payeeAccId;
	  private String dateOfTransfer;
	  private long transferAmt;
	public int getFundId() {
		return fundId;
	}
	public void setFundId(int fundId) {
		this.fundId = fundId;
	}
	public int getSenderAccountNum() {
		return senderAccountNum;
	}
	public void setSenderAccountNum(int senderAccountNum) {
		this.senderAccountNum = senderAccountNum;
	}
	public String getTranspwd() {
		return transpwd;
	}
	public void setTranspwd(String transpwd) {
		this.transpwd = transpwd;
	}
	public int getPayeeAccId() {
		return payeeAccId;
	}
	public void setPayeeAccId(int payeeAccId) {
		this.payeeAccId = payeeAccId;
	}
	public String getDateOfTransfer() {
		return dateOfTransfer;
	}
	public void setDateOfTransfer(String dateOfTransfer) {
		this.dateOfTransfer = dateOfTransfer;
	}
	public long getTransferAmt() {
		return transferAmt;
	}
	public void setTransferAmt(long transferAmt) {
		this.transferAmt = transferAmt;
	}
	  
	  
}
