package com.bank.service;


import com.bank.entity.AccountMaster;
import com.bank.entity.Customer;
import com.bank.entity.UserTable;

public interface IBankService {
	public UserTable check(UserTable user) ;



public AccountMaster getAccountBalance(long accId);



public int  getChangeAddress(long accId, String cadd);



public int getChangeMobNum(long accId,long cmob);



public int getChangeMobNum(long accId, String cpw);


}
