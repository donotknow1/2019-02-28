package com.bank.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;




import com.bank.dao.IBankRepository;
import com.bank.entity.AccountMaster;
import com.bank.entity.Customer;
import com.bank.entity.UserTable;

@Service
@Transactional
public class BankService implements IBankService {
	@Autowired
	private IBankRepository bankRepository;

	public UserTable check(UserTable user) {
		// TODO Auto-generated method stub
		return bankRepository.check(user); 
	}


	@Override
	public AccountMaster getAccountBalance(long accId) {
		// TODO Auto-generated method stub
		return bankRepository.getAccountBalance(accId);
	}


	@Override
	public int getChangeAddress(long accId, String cadd) {
		return bankRepository.getChangeAddress(accId, cadd);
	}


	@Override
	public int getChangeMobNum(long accId,long cmob) {
		return bankRepository.getChangeMobNum(accId, cmob);
	}


	@Override
	public int getChangeMobNum(long accId, String cpw) {
		return bankRepository.getChangeMobNum(accId, cpw);
	}

	
		
		
	

}
