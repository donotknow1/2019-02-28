package com.bank.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;





import com.bank.entity.AccountMaster;
import com.bank.entity.Customer;
import com.bank.entity.UserTable;
import com.bank.service.BankService;
import com.bank.service.IBankService;

@Controller
public class BankController {
	@Autowired
	public IBankService bankService;
	
	 
	static int userId;
	static long accId;
	
	//shows the homepage
	@RequestMapping("/index")
	public String showIndex(Model model){
		return "index";
	}
	
	//login page
	@RequestMapping(value= "/loginPage")
	public String showLoginPage(Model model){
		//model.addAttribute("account", account);
	 model.addAttribute("UserTable",new UserTable());
		return "loginPage";
	}
	//account holder
	//***************************ACCOUNTID***************************
    @RequestMapping(value="/accountHolder")
		public String login(@ModelAttribute("accountHolder")UserTable user,@RequestParam("userId")int uid,Model model){
			userId=uid;
	       model.addAttribute("bank",bankService.check(user));
		   model.addAttribute("message"," successfully loggedin!");
		   user=bankService.check(user);
		UserTable user1=   bankService.check(user);
		accId=user1.getAccountId();
		  System.out.println(accId);    
		  // long accountId= bankService.getAccountId(userid);
		    return "accountHolder";
		} 

    
    //account balance
   
    @RequestMapping(value="/accountBalance")
      public String  showaccountbalance(Model model){
    	 model.addAttribute("accbalance",bankService.getAccountBalance(accId));
    return "accountBalance";
    	  
      }
      
    
    //****************  CHANGE ADDRESSS *****************************************
    @RequestMapping(value= "/changeAddress")
	public String showAddressPage(Model model){
		model.addAttribute("customer",new Customer());
		return  "changeAddress";
	}
    
    
      @RequestMapping(value="/successAdd")
    public String  showchangeAddress(Model model,@ModelAttribute("changeAddress")Customer cust){
    	String cadd=cust.getCustomerAddress();
    model.addAttribute("changeAddress",bankService.getChangeAddress(accId,cadd));
    return "successAdd";
  	  
    }
      
      
      //********************** CHANGEPHONE*****************************************
     @RequestMapping(value= "/changePhone")
  	public String showchangePhone(Model model){
  		model.addAttribute("customer",new Customer());
  		return  "changePhone";
  	}

    @RequestMapping(value="/successPhone")
    public String showchangePhone(Model model,@ModelAttribute("changePhone")Customer cus){
    	long cmob=cus.getCustomerMobNum();
    	model.addAttribute("changePhone",bankService.getChangeMobNum(accId,cmob));
        return "successPhone";
  	  
    }
    //*********************************CHANGEPASSWORD************************************
     
   @RequestMapping(value= "/changePassWord")
  	public String showchangePassWord(Model model){
  		 model.addAttribute("UserTable",new UserTable());
  		return  "changePassWord";
  	}

    @RequestMapping(value="/successPassWord")
    public String showchangePassWord(Model model,@ModelAttribute("changePassWord")UserTable ut){
    	String cpw=ut.getLoginPassword();
    	model.addAttribute("changePhone",bankService.getChangeMobNum(accId,cpw));
        return "successPassWord";
  	  
    }
}


