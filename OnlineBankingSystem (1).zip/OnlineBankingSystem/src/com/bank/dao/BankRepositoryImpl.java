package com.bank.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;






import com.bank.entity.AccountMaster;
import com.bank.entity.Customer;
import com.bank.entity.UserTable;

@Repository
public class BankRepositoryImpl implements IBankRepository {

	@PersistenceContext
	private EntityManager entityManager;

	public UserTable check(UserTable user) {
		String q="SELECT b FROM UserTable b WHERE b.userId=:puid AND b.loginPassword=:ppass";
		TypedQuery<UserTable> query=entityManager.createQuery(q,UserTable.class);
		query.setParameter("puid", user.getUserId());
		System.err.println(user.getUserId());
		query.setParameter("ppass",user.getLoginPassword());
		return query.getSingleResult(); 
		
		
	}
@Override
	public AccountMaster getAccountBalance(long accId) {
		String q="SELECT g FROM AccountMaster g WHERE g.accountId=:paccblnce";
		TypedQuery<AccountMaster> query2=entityManager.createQuery(q,AccountMaster.class);
		query2.setParameter("paccblnce",accId);
		return  query2.getSingleResult();
	}
@Override
public int getChangeAddress(long accId, String cadd) {
	String q = "UPDATE Customer c SET c.customerAddress=:padd WHERE c.accountId=:pId";
	//System.out.println("AccId: "+accId);
	//System.out.println("cadd: "+cadd);
	Query query=entityManager.createQuery(q);
	query.setParameter("pId", accId);
	query.setParameter("padd",cadd);
	return  query.executeUpdate(); 
}
@Override
public int getChangeMobNum(long accId, long cmob) {
	String q1 = "UPDATE Customer c SET c.customerMobNum=:pmob WHERE c.accountId=:pId";
	Query query=entityManager.createQuery(q1);
	query.setParameter("pId", accId);
	query.setParameter("pmob", accId);
	return  query.executeUpdate(); 
}
@Override
public int getChangeMobNum(long accId, String cpw) {
	String q1 = "UPDATE UserTable u SET u.loginPassword=:plpw WHERE u.accountId=:pId";
	Query query=entityManager.createQuery(q1);
	query.setParameter("pId", accId);
	query.setParameter("plpw", accId);
	return  query.executeUpdate(); 
}
}
